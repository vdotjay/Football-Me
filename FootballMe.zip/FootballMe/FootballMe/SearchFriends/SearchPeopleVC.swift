//
//  SearchPeopleVC.swift
//  FootballMe
//
//  Created by  Vj Dubb on 06/04/2020.
//  Copyright © 2020 Vijender Dubb. All rights reserved.
//

import UIKit
import FirebaseAuth
import FirebaseDatabase
import FirebaseStorage

class SearchPeopleVC: UIViewController {
    
    var searchUser = [UserData]()

    let ref = Database.database().reference()
    let storageRef = Storage.storage().reference()
    
    @IBOutlet weak var tableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func onBack(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
}


extension SearchPeopleVC : UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return searchUser.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "CELL", for: indexPath) as! SearchTableCell
        cell.userImage.image = searchUser[indexPath.row].image
        cell.userNameLabel.text = searchUser[indexPath.row].name
        cell.status.text = "View Profile"
        
        return cell
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let otherUser = searchUser[indexPath.row].userID!
        ref.child(DBKeys.DBFriendsKey).child(Auth.auth().currentUser!.uid).observeSingleEvent(of: .value, with: {snapshot in
            if let users = snapshot.value as? [String:Any] {
                var found = false
                for user in users {
                    if user.key == otherUser {
                        found = true
                        let vc = OtherUserVC(nibName: "OtherUserVC", bundle: .main) as OtherUserVC
                        vc.user = self.searchUser[indexPath.row]
                        self.navigationController?.pushViewController(vc, animated: true)
                    }
                }
                
                if !found {
                    let vc = SearchedProfileVC(nibName: "SearchedProfileVC", bundle: .main) as SearchedProfileVC
                    vc.userData = self.searchUser[indexPath.row]
                    self.navigationController?.pushViewController(vc, animated: true)
                }
                
                
            
            } else {
                let vc = SearchedProfileVC(nibName: "SearchedProfileVC", bundle: .main) as SearchedProfileVC
                vc.userData = self.searchUser[indexPath.row]
                self.navigationController?.pushViewController(vc, animated: true)
            }
        })
        
        /*let vc = SearchedProfileVC(nibName: "SearchedProfileVC", bundle: .main) as SearchedProfileVC
        vc.userData = searchUser[indexPath.row]
        self.navigationController?.pushViewController(vc, animated: true)*/
        
    }
    
}

extension SearchPeopleVC : UISearchBarDelegate {
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        
        ref.child(DBKeys.DBUserKey).queryOrdered(byChild: DBKeys.DBNameKey).queryStarting(atValue: searchBar.text!).queryEnding(atValue: searchBar.text!+"\u{f8ff}").observeSingleEvent(of: .value, with: {(snapshot) in
            
            guard let users = snapshot.value as? [String:Any] else {
                print("No User Found")
                return
            }
            self.searchUser.removeAll()
            for user in users {
                
                if (user.key != Auth.auth().currentUser!.uid) {
                    let userData = UserData()
                    userData.userID = user.key
                    let data = user.value as? NSDictionary
                    
                    if let name = data?[DBKeys.DBNameKey] as? String {
                        userData.name = name
                    } else {return}
                    
                    if let dob = data?[DBKeys.DBDOBKey] as? String {
                        userData.dob = dob
                    } else {return}
                    
                    if let phone = data?[DBKeys.DBPhoneKey] as? String {
                        userData.phone = phone
                    } else {return}
                    
                    if let username = data?[DBKeys.DBUserNameKey] as? String {
                        userData.userName = username
                    } else {return}
                    print(user.key)
                    if let availability = data?[DBKeys.DBAvailabilityKey] as? Bool {
                        userData.availability = availability
                    } else {return}
                    
                    self.storageRef.child(user.key).getData(maxSize: 1 * 1024 * 1024, completion: {data, error in
                        if let error = error {
                            userData.image = UIImage(named: "user")
                            print(error.localizedDescription)
                            
                        } else {
                            userData.image = UIImage(data: data!)
                            
                        }
                        self.searchUser.append(userData)
                        self.tableView.reloadData()
                    })
                    
                    
                }
                
            }
            
            
            
        })
        
        
    }
    
}
