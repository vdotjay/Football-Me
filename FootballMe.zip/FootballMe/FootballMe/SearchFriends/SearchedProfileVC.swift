//
//  SearchedProfileVC.swift
//  FootballMe
//
//  Created by  Vj Dubb on 10/04/2020.
//  Copyright © 2020 Vijender Dubb. All rights reserved.
//

import UIKit
import FirebaseAuth
import FirebaseDatabase

class SearchedProfileVC: UIViewController {
    
    var userData = UserData()
    
    @IBOutlet weak var userImage: UIImageView!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var dobLabel: UILabel!
    @IBOutlet weak var phoneNumberLabel: UILabel!
    @IBOutlet weak var availabilityLabel: UILabel!
    
    @IBOutlet weak var requestButton: UIButton!
    
    let uid = Auth.auth().currentUser!.uid
    let ref = Database.database().reference()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        userImage.image = userData.image
        nameLabel.text = userData.name
        dobLabel.text = userData.dob
        phoneNumberLabel.text = userData.phone
        availabilityLabel.text = userData.availability! ? "Yes" : "No"
        
        ref.child(DBKeys.DBFriendRequestKey).queryOrdered(byChild: "from").queryStarting(atValue: uid).queryEnding(atValue: uid+"\u{f8ff}").observeSingleEvent(of: .value, with: {snapshot in
            
            if let requests = snapshot.value as? [String:Any] {
                
                if let _ = self.uidExistInSentRequests(requests: requests) {
                    self.setRequestButton(color: .green, text: "Request Sent")
                } else {
                    self.setRequestButton(color: .blue, text: "Send friend request")
                }
            }
        })
        
    }
    
    @IBAction func onClickBack(_ sender: UIButton) {
        
        self.navigationController?.popViewController(animated: true)
        
    }
    
    
    @IBAction func onClickRequestButton(_ sender: UIButton) {
        
        ref.child(DBKeys.DBFriendRequestKey).queryOrdered(byChild: "from").queryStarting(atValue: uid).queryEnding(atValue: uid+"\u{f8ff}").observeSingleEvent(of: .value, with: {snapshot in
            
            if let requests = snapshot.value as? [String:Any] {
                
                if let key = self.uidExistInSentRequests(requests: requests) {
                    self.ref.child(DBKeys.DBFriendRequestKey).child(key).removeValue()
                    self.setRequestButton(color: .blue, text: "Send friend request")
                } else {
                    self.ref.child(DBKeys.DBFriendRequestKey).childByAutoId().setValue(["from": self.uid, "to":self.userData.userID])
                    self.setRequestButton(color: .green, text: "Request Sent")
                }
                
            } else {
                self.ref.child(DBKeys.DBFriendRequestKey).childByAutoId().setValue(["from": self.uid, "to":self.userData.userID])
                self.setRequestButton(color: .green, text: "Request Sent")
            }
            
        })
        
    }
    
    func uidExistInSentRequests (requests: [String:Any]) -> String? {
        
        for request in requests {
            
            let dictionary = request.value as? NSDictionary
            
            guard let recieverID = dictionary?["to"] as? String else {return nil}
            
            if recieverID == userData.userID {
                return request.key
            }
            
        }
        
        return nil
    }
    
    func setRequestButton(color: UIColor, text: String) {
        
        self.requestButton.setTitleColor(color, for: .normal)
        self.requestButton.setTitle(text, for: .normal)
        
    }
    
}
