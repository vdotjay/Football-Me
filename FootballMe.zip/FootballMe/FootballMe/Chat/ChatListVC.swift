//
//  ChatVC.swift
//  FootballMe
//
//  Created by  Vj Dubb on 05/04/2020.
//  Copyright © 2020 Vijender Dubb. All rights reserved.
//

import UIKit
import FirebaseAuth
import FirebaseDatabase
import FirebaseStorage

class ChatListVC: UIViewController {
    
    var chatIds = [String]()
    var chatList = [UserData]()
    
    let ref = Database.database().reference()
    let storageRef = Storage.storage().reference()
    let uid = Auth.auth().currentUser!.uid

    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var userImage: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        getChatList()
        
        let gesture = UITapGestureRecognizer(target: self, action: #selector(openUser(sender:)))
        userImage.isUserInteractionEnabled = true
        userImage.addGestureRecognizer(gesture)
        
        storageRef.child(uid).getData(maxSize: 1 * 1024 * 1024, completion: {(data, error) in
            
            if let  error = error {
                print(error.localizedDescription)
                self.userImage.image = UIImage(named: "user")
                return
            }
            
            if let data = data {
                let image = UIImage(data: data)
                self.userImage.image = image
                
            }
            
        })
    }
    
    @objc func openUser (sender: UIGestureRecognizer) {
        let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "USER_PAGE")
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func openEvents(_ sender: UIButton) {
        
        let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "EVENTS_PAGE") as! EventsVC
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    
    func getChatList() {
        self.chatList.removeAll()
        self.chatIds.removeAll()
        ref.child(DBKeys.DBChatidKey).queryOrdered(byChild: uid).observeSingleEvent(of: .value, with: {snapshot in
            
            if let myChats = snapshot.value as? [String:Any] {
                
                for chat in myChats {
                    
                    let participants = chat.value as? NSDictionary
                    
                    if let _ = participants?[self.uid] as? Bool {
                        
                        for participant in participants?.allKeys as! [String] {
                            if participant != self.uid {
                                
                                self.ref.child(DBKeys.DBUserKey).child(participant).observeSingleEvent(of: .value, with: {snapshot in
                                    
                                    if let userData = snapshot.value as? [String:Any] {
                                        let user = UserData()
                                        for data in userData {
                                            
                                            if data.key == DBKeys.DBNameKey {
                                                user.name = data.value as? String
                                            } else if data.key == DBKeys.DBDOBKey {
                                                user.dob = data.value as? String
                                            } else if data.key == DBKeys.DBAvailabilityKey {
                                                user.availability = data.value as? Bool
                                            } else if data.key == DBKeys.DBPhoneKey {
                                                user.phone = data.value as? String
                                            } else if data.key == DBKeys.DBUserNameKey {
                                                user.userName = data.value as? String
                                            }
                                            
                                        }
                                        self.storageRef.child(participant).getData(maxSize: 1 * 1024 * 1024, completion: {data, error in
                                            
                                            if let error = error {
                                                user.image = UIImage(named: "user")
                                                print(error)
                                            } else {
                                                user.image = UIImage(data: data!)
                                            }
                                            
                                            user.userID = participant
                                            self.chatList.append(user)
                                            self.chatIds.append(chat.key)
                                            self.tableView.reloadData()
                                        })
                                        
                                        
                                    }
                                    
                                })
                                
                            }
                        }
                        
                    }else {}
                    
                }
                
                
                
            }
            
        })
        
    }
    
    @IBAction func onClickUser(_ sender: UIButton) {
        
        let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "USER_PAGE")
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    
    @IBAction func onClickSearchFriends(_ sender: UIButton) {
        
        let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "SEARCH_PAGE")
        
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    
    @IBAction func onClickFriends(_ sender: UIButton) {
        let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "REQUEST_PAGE")
        
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func onClickAllFriends(_ sender: UIButton) {
        let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "MYFRIENDS_PAGE")
        
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
}

extension ChatListVC : UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return chatList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CELL", for: indexPath) as! ChatTableCell
        
        cell.chatImage.image = chatList[indexPath.row].image
        cell.chatName.text = chatList[indexPath.row].name
        
        return cell
    
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "CHAT_PAGE") as! ChatVC
        vc.user = self.chatList[indexPath.row]
        vc.chatID = self.chatIds[indexPath.row]
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    
}
/*self.ref.child(DBKeys.DBUserKey).child(participant).observeSingleEvent(of: .value, with: {snapshot in
 
 if let userData = snapshot.value as? [String:Any] {
 let user = UserData()
 for data in userData {
 
 if data.key == DBKeys.DBNameKey {
 user.name = data.value as? String
 } else if data.key == DBKeys.DBDOBKey {
 user.dob = data.value as? String
 } else if data.key == DBKeys.DBAvailabilityKey {
 user.availability = data.value as? Bool
 } else if data.key == DBKeys.DBPhoneKey {
 user.phone = data.value as? String
 } else if data.key == DBKeys.DBUserNameKey {
 user.userName = data.value as? String
 }
 
 }
 user.image = UIImage(named: "user")
 user.userID = participant
 self.chatList.append(user)
 
 }
 self.tableView.reloadData()
 })*/
