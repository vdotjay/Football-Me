
import Foundation
import UIKit


public class ChatList {
    
    public var chatName: String
    public var chatImage : UIImage
    
    init(chatName: String, chatImage: UIImage) {
        self.chatName = chatName
        self.chatImage = chatImage
    }
    
}

public class Chat {
    
    public var senderID: String = ""
    public var message: String = ""
    public var timeStamp : NSNumber = 0
    
}
