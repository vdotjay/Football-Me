//
//  ChatVC.swift
//  FootballMe
//
//  Created by  Vj Dubb on 16/04/2020.
//  Copyright © 2020 Vijender Dubb. All rights reserved.
//

import UIKit
import FirebaseAuth
import FirebaseDatabase

class ChatVC: UIViewController {
    
    var chatID : String? = nil
    var user = UserData()
    
    @IBOutlet weak var messageField: UITextView!
    var messages = [Chat]()
    
    @IBOutlet weak var messageCollection: UICollectionView!
    
    
    let ref = Database.database().reference()
    let uid = Auth.auth().currentUser!.uid
    
    override func viewDidLoad() {
        super.viewDidLoad()
        getPreviosMessages ()
        // Do any additional setup after loading the view.
    }
    @IBAction func onMessageSend(_ sender: UIButton) {
        
        ref.child(DBKeys.DBChatsKey).child(chatID!).childByAutoId().setValue(["senderID": uid, "message": messageField.text!, "timestamp": Date().timeIntervalSince1970])
        
        messageField.text = ""
        
    }
    
    @IBAction func onBack(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
    func getPreviosMessages () {
        
        ref.child(DBKeys.DBChatsKey).child(chatID!).observe(.value, with: {snapshot in
            
            self.messages.removeAll()
            
            if let messages = snapshot.value as? [String:Any] {
                
                for message in messages {
                    
                    let chat = Chat()
                    
                    let mdict = message.value as? NSDictionary
                    
                    chat.senderID = mdict?["senderID"] as! String
                    chat.message = mdict?["message"] as! String
                    chat.timeStamp = mdict?["timestamp"] as! NSNumber
                    
                    self.messages.append(chat)
                    
                    self.messages = self.messages.sorted(by: { Int(truncating: $0.timeStamp) < Int(truncating: $1.timeStamp) })
                    
                }
                
            } else {
                print("No message in chat")
            }
            
            self.messageCollection.reloadData()
            
        })
        
    }
    
}

extension ChatVC : UICollectionViewDelegate, UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return messages.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CELL", for: indexPath) as! ChatCell
        
        if messages[indexPath.row].senderID == uid {
            cell.myMessage.text = messages[indexPath.row].message
            cell.myMessage.backgroundColor = .blue
            cell.myMessage.textColor = .white
            cell.myMessage.layer.cornerRadius = 10
            
            cell.myMessage.translatesAutoresizingMaskIntoConstraints = true
            cell.myMessage.sizeToFit()
            cell.myMessage.isScrollEnabled = false
            
            cell.othersMessage.isHidden = true
        } else {
            cell.othersMessage.text = messages[indexPath.row].message
            cell.othersMessage.backgroundColor = .lightGray
            cell.othersMessage.textColor = .black
            cell.othersMessage.layer.cornerRadius = 10
            cell.myMessage.isHidden = true
            cell.othersMessage.translatesAutoresizingMaskIntoConstraints = true
            cell.othersMessage.sizeToFit()
            cell.othersMessage.isScrollEnabled = false
            
        }
        return cell
    }
       
    
    
}

class ChatCell: UICollectionViewCell {
    
    @IBOutlet weak var othersMessage: UITextView!
    @IBOutlet weak var myMessage: UITextView!
    
}


