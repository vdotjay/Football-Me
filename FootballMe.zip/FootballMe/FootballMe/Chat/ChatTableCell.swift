//
//  ChatTableCell.swift
//  FootballMe
//
//  Created by  Vj Dubb on 05/04/2020.
//  Copyright © 2020 Vijender Dubb. All rights reserved.
//

import UIKit

class ChatTableCell: UITableViewCell {

    @IBOutlet weak var chatImage: UIImageView!
    
    @IBOutlet weak var chatName: UILabel!
    
}
