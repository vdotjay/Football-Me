//
//  ViewController.swift
//  FootballMe
//
//  Created by  Vj Dubb on 02/04/2020.
//  Copyright © 2020 Vijender Dubb. All rights reserved.
//

import UIKit
import SwiftKeychainWrapper
import FirebaseAuth
import FirebaseDatabase

class LoginViewController: UIViewController {
    
    
    @IBOutlet weak var emailField: UITextField!
    
    @IBOutlet weak var passwordField: UITextField!
    
    var userUid: String!
    
    
    let backgroundImageView = UIImageView()

    override func viewDidLoad() {
        super.viewDidLoad()
        setBackground()
        
        if (Auth.auth().currentUser != nil) {
            openChatPage()
        }
    
    }
    
    func setBackground(){
        view.addSubview(backgroundImageView)
        backgroundImageView.translatesAutoresizingMaskIntoConstraints = false
        backgroundImageView.topAnchor.constraint(equalTo: view.topAnchor).isActive = true
        backgroundImageView.bottomAnchor.constraint(equalTo: view.bottomAnchor).isActive = true
        backgroundImageView.leadingAnchor.constraint(equalTo: view.leadingAnchor).isActive = true
        backgroundImageView.trailingAnchor.constraint(equalTo: view.trailingAnchor).isActive = true
        
        backgroundImageView.image = UIImage(named: "image-12")
        view.sendSubviewToBack(backgroundImageView)
    }
    
    func openChatPage () {
        let vc = UIStoryboard(name: "Main", bundle:
            nil).instantiateViewController(withIdentifier: "CHATLIST_PAGE")
        self.navigationController?.pushViewController(vc, animated: true)
        
        //CHATLIST_PAGE
    }
    
    //UI Button Actions
    
    @IBAction func openSinup(_ sender: UIButton) {
        
        let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "SIGNUP_PAGE")
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    
    @IBAction func onLogin(_ sender: UIButton) {
        
        Auth.auth().signIn(withEmail: emailField.text!, password: passwordField.text!, completion: {(result, error) in
            
            if let error = error {
                print(error.localizedDescription)
                return
            }
            
            let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "CHATLIST_PAGE")
            
            self.navigationController?.pushViewController(vc, animated: true)
        })
        
    }
    
    @IBAction func forgotPassword(_ sender: UIButton) {
        
        Auth.auth().sendPasswordReset(withEmail: emailField.text!, completion: {(sent) in
            
            Utility.showAlert(sender: self, title: "Confirmation", message: "Reset password has been sent to \(self.emailField.text!)")
            
        })
        
    }
    
    
}
