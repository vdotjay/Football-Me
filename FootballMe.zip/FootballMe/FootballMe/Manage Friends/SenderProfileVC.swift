//
//  SenderProfileVC.swift
//  FootballMe
//
//  Created by  Vj Dubb on 10/04/2020.
//  Copyright © 2020 Vijender Dubb. All rights reserved.
//

import UIKit
import FirebaseAuth
import FirebaseDatabase

class SenderProfileVC: UIViewController {

    var userData = UserData()
    
    var requestKey : String = ""
    
    @IBOutlet weak var userImage: UIImageView!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var dobLabel: UILabel!
    @IBOutlet weak var phoneNumberLabel: UILabel!
    @IBOutlet weak var availabilityLabel: UILabel!
    
    
    let uid = Auth.auth().currentUser!.uid
    let ref = Database.database().reference()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        nameLabel.text = userData.name
        dobLabel.text = userData.dob
        phoneNumberLabel.text = userData.phone
        availabilityLabel.text = userData.availability! ? "Yes" : "No"
        
    }

    @IBAction func onClickBackButton(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func onAccept(_ sender: UIButton) {
        
        let senderID : String = userData.userID!
        
        ref.child(DBKeys.DBFriendsKey).child(uid).child(senderID).setValue(true)
        ref.child(DBKeys.DBFriendsKey).child(senderID).child(uid).setValue(true)
        removeRequest()
    }
    
    @IBAction func onReject(_ sender: UIButton) {
        removeRequest()
    }
    
    func removeRequest () {
        ref.child(DBKeys.DBFriendRequestKey).child(requestKey).removeValue()
        self.navigationController?.popViewController(animated: true)
    }
    
}
