//
//  FriendRequestCell.swift
//  FootballMe
//
//  Created by  Vj Dubb on 11/04/2020.
//  Copyright © 2020 Vijender Dubb. All rights reserved.
//

import UIKit

class FriendRequestCell: UITableViewCell {

    @IBOutlet weak var userImage: UIImageView!
    @IBOutlet weak var userName: UILabel!
    

}
