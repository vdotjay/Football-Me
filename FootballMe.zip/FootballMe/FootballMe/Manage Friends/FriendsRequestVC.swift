//
//  FriendsRequestVC.swift
//  FootballMe
//
//  Created by  Vj Dubb on 08/04/2020.
//  Copyright © 2020 Vijender Dubb. All rights reserved.
//

import UIKit
import FirebaseDatabase
import FirebaseAuth

class FriendsRequestVC: UIViewController {
    
    @IBOutlet weak var tableView : UITableView!
    
    var requestingUIDs = [String]()
    var requestingKeys = [String]()
    var friendRequests = [UserData]()
    let ref = Database.database().reference()
    let uid = Auth.auth().currentUser!.uid
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        requestingUIDs.removeAll()
        requestingKeys.removeAll()
        friendRequests.removeAll()
        getRequestinUIDs()
    }
    
    func getRequestinUIDs () {
        
        ref.child(DBKeys.DBFriendRequestKey).queryOrdered(byChild: "to").queryStarting(atValue: uid).queryEnding(atValue: uid+"\u{f8ff}").observeSingleEvent(of: .value, with: {snapshot in
            
            if let requests = snapshot.value as? [String:Any] {
                
                for request in requests {
                    
                    let reqUIDs = request.value as? NSDictionary
                    
                    guard let senderID = reqUIDs?["from"] as? String else {return}
                    self.requestingUIDs.append(senderID)
                    self.requestingKeys.append(request.key)
                    
                }
                
            } else {
                print("You have no pending friend request")
            }
            self.getProfilesOfRequestingUIDs()
            
        })
        
    }
    
    func getProfilesOfRequestingUIDs () {
        
        var user: UserData? = nil
        
        for ruid in requestingUIDs {
            //print(ruid)
            ref.child(DBKeys.DBUserKey).child(ruid).observeSingleEvent(of: .value, with: {snapshot in
                
                let userData = snapshot.value as? [String:Any]
                user = UserData()
                
                for data in userData! {
                    
                    if data.key == DBKeys.DBNameKey {
                        user!.name = data.value as? String
                    } else if data.key == DBKeys.DBDOBKey {
                        user!.dob = data.value as? String
                    } else if data.key == DBKeys.DBAvailabilityKey {
                        user!.availability = data.value as? Bool
                    } else if data.key == DBKeys.DBPhoneKey {
                        user!.phone = data.value as? String
                    } else if data.key == DBKeys.DBUserNameKey {
                        user!.userName = data.value as? String
                    }
                    
                }
                user?.image = UIImage(named: "user")
                user?.userID = ruid
                self.friendRequests.append(user!)
                print(user!.name!)
                print(self.friendRequests.count)
                self.tableView.reloadData()
                
            })
        }
    }
    
    @IBAction func onBack(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
}

extension FriendsRequestVC: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return friendRequests.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CELL", for: indexPath) as! FriendRequestCell
        cell.imageView?.image = friendRequests[indexPath.row].image
        cell.userName?.text = friendRequests[indexPath.row].name
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let vc = SenderProfileVC(nibName: "SenderProfileVC", bundle: .main) as SenderProfileVC
        vc.userData = friendRequests[indexPath.row]
        vc.requestKey = requestingKeys[indexPath.row]
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    
}
