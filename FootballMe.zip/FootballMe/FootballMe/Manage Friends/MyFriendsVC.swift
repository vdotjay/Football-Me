//
//  MyFriendsVC.swift
//  FootballMe
//
//  Created by  Vj Dubb on 11/04/2020.
//  Copyright © 2020 Vijender Dubb. All rights reserved.
//

import UIKit
import FirebaseAuth
import FirebaseDatabase
import FirebaseStorage

class MyFriendsVC: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    
    let uid = Auth.auth().currentUser!.uid
    let ref = Database.database().reference()
    let storageRef = Storage.storage().reference()
    
    var myFriends = [UserData]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        ref.child(DBKeys.DBFriendsKey).child(uid).observeSingleEvent(of: .value, with: {snapshot in
            
            if let friends = snapshot.value as? [String:Any] {
                
                for friend in friends {
                    
                    self.ref.child(DBKeys.DBUserKey).child(friend.key).observeSingleEvent(of: .value, with: {snapshot in
                        
                        if let userData = snapshot.value as? [String:Any] {
                            let user = UserData()
                            for data in userData {
                                if data.key == DBKeys.DBNameKey {
                                    user.name = data.value as? String
                                } else if data.key == DBKeys.DBDOBKey {
                                    user.dob = data.value as? String
                                } else if data.key == DBKeys.DBAvailabilityKey {
                                    user.availability = data.value as? Bool
                                } else if data.key == DBKeys.DBPhoneKey {
                                    user.phone = data.value as? String
                                } else if data.key == DBKeys.DBUserNameKey {
                                    user.userName = data.value as? String
                                }
                            }
                            user.userID = friend.key
                            self.storageRef.child(friend.key).getData(maxSize: 1 * 1024 * 1024, completion: {data, error in
                                
                                if let error = error {
                                    user.image = UIImage(named: "user")
                                    self.myFriends.append(user)
                                    print(error)
                                } else {
                                    user.image = UIImage(data: data!)
                                    self.myFriends.append(user)
                                }
                                self.tableView.reloadData()
                            })
                            
                            
                            
                        }
                        
                    })
                    
                }
                
            }
            
            
            
        })
        
    }
    
    @IBAction func onBack (_ sender: UIButton) {
        
        self.navigationController?.popViewController(animated: true)
        
    }


}

extension MyFriendsVC: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return myFriends.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CELL", for: indexPath) as! MyFriendsCell
        cell.userImage.image = myFriends[indexPath.row].image
        cell.userName.text = myFriends[indexPath.row].name
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let vc = OtherUserVC(nibName: "OtherUserVC", bundle: .main) as OtherUserVC
        vc.user = myFriends[indexPath.row]
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    
}
