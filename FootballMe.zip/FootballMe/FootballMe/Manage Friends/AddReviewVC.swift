//
//  AddReviewVC.swift
//  FootballMe
//
//  Created by  Vj Dubb on 21/04/2020.
//  Copyright © 2020 Vijender Dubb. All rights reserved.
//

import UIKit
import FirebaseDatabase

class AddReviewVC: UIViewController {
    
    let ref = Database.database().reference()
    var user = UserData()
    
    @IBOutlet var userImage : UIImageView!
    @IBOutlet var nameLabel : UILabel!
    @IBOutlet var reviewField: UITextView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        userImage.image = user.image
        nameLabel.text = user.name
        // Do any additional setup after loading the view.
        
        reviewField.layer.borderWidth = 1.0
        reviewField.layer.cornerRadius = 6
        reviewField.layer.borderColor = UIColor.gray.cgColor
    }
    
    @objc func hideKeyboard (_ sender: UIGestureRecognizer) {
        self.view.endEditing(true)
    }
    
    @IBAction func onSubmit (_ sender : UIButton) {
        
        if reviewField.text!.count > 0 {
            ref.child(DBKeys.DBReviewKey).child(user.userID!).childByAutoId().setValue(reviewField.text!)
            reviewField.text = ""
        }
        
    }
    
    @IBAction func onBack (_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }

}
