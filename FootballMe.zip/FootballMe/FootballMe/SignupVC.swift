//
//  SignupVC.swift
//  FootballMe
//
//  Created by  Vj Dubb on 05/04/2020.
//  Copyright © 2020 Vijender Dubb. All rights reserved.
//

import UIKit
import FirebaseAuth
import FirebaseDatabase
import FirebaseStorage

class SignupVC: UIViewController {
    
    
    @IBOutlet weak var nameField: UITextField!
    @IBOutlet weak var emailField: UITextField!
    @IBOutlet weak var usernameField: UITextField!
    @IBOutlet weak var passwordField: UITextField!
    @IBOutlet weak var phoneField: UITextField!
    @IBOutlet weak var dopPicker: UIDatePicker!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        setBackground()
        
                
    }
    
    
    @IBAction func onSignup(_ sender: UIButton) {
        
        let name = nameField.text!
        let email = emailField.text!
        let username = usernameField.text!
        let password = passwordField.text!
        let phone = phoneField.text!
        
        let formatter = DateFormatter()
        formatter.dateFormat = "MM-dd-yyyy"
        let dob = formatter.string(from: dopPicker.date)
        
        //Put check here........
        
        if (name.count <= 2) {
            Utility.showAlert(sender: self, title: "Error", message: "Invalid Name")
        }
        
        if !validateName(name: name) {
            Utility.showAlert(sender: self, title: "Error", message: "Name cannot contain digits")
        }
        
        if username.count <= 2 {
            Utility.showAlert(sender: self, title: "Error", message: "Invalid Username")
        }
        
        if phone.count <= 6 {
            Utility.showAlert(sender: self, title: "Error", message: "Invalid phone number")
        }
        
        if !validate(password: password) {
            Utility.showAlert(sender: self, title: "Error", message: "Password must contain at least one capital Letter and one number")
        }
        
        
        Auth.auth().fetchSignInMethods(forEmail: email, completion: {(providers, error) in
            
            if let error = error {
                print("Error", error.localizedDescription)
                return
            }
            
            if let providers = providers {
                print("Email already exits", providers)
                return
            }
            
            Auth.auth().createUser(withEmail: email, password: password, completion: {(results, error) in
                
                if let error = error {
                    print(error.localizedDescription)
                    
                    let alert = UIAlertController(title: "Error", message: error.localizedDescription, preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: "Dismiss", style: .default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                    
                    return
                }
                
                let ref = Database.database().reference()
                let storageRef = Storage.storage().reference()
                
                let uid = (Auth.auth().currentUser?.uid)!
                
                ref.child("users").child(uid).setValue(["name" : name, "username" : username, "phone" : phone, "dob" : dob, "availability" : true])
                
                let image = UIImage(named: "user")?.pngData()
                
                storageRef.child(uid).putData(image!)
                
                //temporary alert
                let alert = UIAlertController(title: "Confirmation", message: "Signup was successful", preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "Dismiss", style: .default, handler: {_ in
                    
                    let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "CHATLIST_PAGE")
                    self.navigationController?.pushViewController(vc, animated: true)
                    
                }))
                self.present(alert, animated: true, completion: nil)
                
            })
            
        })
        
    }
    
    @IBAction func back (_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
    func setBackground(){
        let backgroundImageView = UIImageView()
        view.addSubview(backgroundImageView)
        backgroundImageView.translatesAutoresizingMaskIntoConstraints = false
        backgroundImageView.topAnchor.constraint(equalTo: view.topAnchor).isActive = true
        backgroundImageView.bottomAnchor.constraint(equalTo: view.bottomAnchor).isActive = true
        backgroundImageView.leadingAnchor.constraint(equalTo: view.leadingAnchor).isActive = true
        backgroundImageView.trailingAnchor.constraint(equalTo: view.trailingAnchor).isActive = true
        
        backgroundImageView.image = UIImage(named: "image-12")
        view.sendSubviewToBack(backgroundImageView)
    }
    
    func validate(password: String) -> Bool {
        let capitalLetterRegEx  = ".*[A-Z]+.*"
        let texttest = NSPredicate(format:"SELF MATCHES %@", capitalLetterRegEx)
        guard texttest.evaluate(with: password) else { return false }
    
        let numberRegEx  = ".*[0-9]+.*"
        let texttest1 = NSPredicate(format:"SELF MATCHES %@", numberRegEx)
        guard texttest1.evaluate(with: password) else { return false }
        
        return true
    }
    
    func validateName (name: String) -> Bool {
        
        let numberRegEx  = ".*[0-9]+.*"
        let texttest1 = NSPredicate(format:"SELF MATCHES %@", numberRegEx)
        guard texttest1.evaluate(with: name) else { return true }
        
        return false
        
    }
    
    
}
