//
//  SAButton.swift
//  FootballMe
//
//  Created by  Vj Dubb on 02/04/2020.
//  Copyright © 2020 Vijender Dubb. All rights reserved.
//

import UIKit

class SAButton: UIButton {

    override init(frame: CGRect) {
        super.init(frame: frame)
        setupButton()
    }
    
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        setupButton()
    }
    
    
    private func setupButton() {
        backgroundColor     = UIColor(red: 2.0/255.0, green: 139.0/255.0, blue: 193.0/255.0, alpha: 1.0)
        titleLabel?.font    = UIFont(name: "avenirNextCondensedDemiBold", size: 22)
        layer.cornerRadius  = frame.size.height/2
        setTitleColor(.white, for: .normal)
    }
}
