//
//  EventMapVC.swift
//  FootballMe
//
//  Created by Vj Dubb on 07/05/2020.
//  Copyright © 2020 Vijender Dubb. All rights reserved.
//

import UIKit
import MapKit
import FirebaseDatabase
import FirebaseAuth

class EventMapVC: UIViewController, MKMapViewDelegate {
    
    @IBOutlet weak var mapView: MKMapView!
    
    let ref = Database.database().reference()
    let uid = Auth.auth().currentUser!.uid
    
    var events = [Event]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        mapView.delegate = self
        
        ref.child(DBKeys.DBEventsKey).observe(.value, with: {snapshot in
            
            //print(snapshot.value)
            
            for snap in snapshot.children {
                
                let event = snap as! DataSnapshot
                
                let eventDictionary = event.value as? NSDictionary
                
                //print(eventDictionary?["hostid"] as! String)
                let hostId = eventDictionary?["hostid"] as! String
                //print(eventDictionary?["event address"] as! String)
                
                let eventName = eventDictionary?["eventname"] as! String
                
                let address = eventDictionary?["event address"] as! String
                
                let eventTime = eventDictionary?["eventtime"] as! String
                
                let locationDict = eventDictionary?["event Location"] as? NSDictionary
                
                //print(locationDict?["latitude"] as! NSNumber)
                let latitude = locationDict?["latitude"] as! NSNumber
                //print(locationDict?["longitude"] as! NSNumber)
                let longitude = locationDict?["longitude"] as! NSNumber
                
                let location = CLLocation(latitude: CLLocationDegrees(exactly: latitude)!, longitude: CLLocationDegrees(exactly: longitude)!)
                
                self.events.append(Event(eventId: event.key, hostId: hostId, name: eventName, address: address, eventTime: eventTime, locationCoordinates: location))
                
            }
            
            for event in self.events {
                
                let annotation = MKPointAnnotation()
                annotation.title = event.name
                annotation.coordinate = event.locationCoordinates.coordinate
                self.mapView.addAnnotation(annotation)
                
            }
            
        })
        
    }
    
    
    func mapView(_ mapView: MKMapView, didSelect view: MKAnnotationView) {
        
        let vc = EventDetailsVC(nibName: "EventDetailsVC", bundle: .main) as EventDetailsVC
        
        if let data = events.enumerated().first(where: {$0.element.locationCoordinates.coordinate.latitude == view.annotation?.coordinate.latitude && $0.element.locationCoordinates.coordinate.longitude == view.annotation?.coordinate.longitude}) {
            vc.event = data.element
            self.navigationController?.pushViewController(vc, animated: true)
        } else {
           print("No a location")
        }
        
    }
    
    @IBAction func onBack (_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func addEvent(_ sender: UIButton) {
        let vc = AddEventVC(nibName: "AddEventVC", bundle: .main)
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func findEvent(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
}
