//
//  MyEventsVC.swift
//  FootballMe
//
//  Created by Vj Dubb on 05/05/2020.
//  Copyright © 2020 Vijender Dubb. All rights reserved.
//

import UIKit
import FirebaseDatabase
import FirebaseAuth
import CoreLocation

class MyEventsVC: UIViewController {
    
    let uid = Auth.auth().currentUser!.uid
    let ref = Database.database().reference()

    @IBOutlet weak var tableView: UITableView!
    
    var events = [Event]()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        ref.child(DBKeys.DBMyEventKey).child(uid).observeSingleEvent(of: .value, with: {snapshot in
            
            if let myEvents = snapshot.value as? [String: Any] {
                
                
                for event in myEvents {
                    
                    
                    self.ref.child(DBKeys.DBEventsKey).child(event.key).observeSingleEvent(of: .value, with: {snapshot in
                        
                        let eventDictionary = snapshot.value as? NSDictionary
                        //print(eventDictionary?["hostid"] as! String)
                        let hostId = eventDictionary?["hostid"] as! String
                        //print(eventDictionary?["event address"] as! String)
                        
                        let eventName = eventDictionary?["eventname"] as! String
                        
                        let address = eventDictionary?["event address"] as! String
                        
                        let eventTime = eventDictionary?["eventtime"] as! String
                        
                        let locationDict = eventDictionary?["event Location"] as? NSDictionary
                        
                        //print(locationDict?["latitude"] as! NSNumber)
                        let latitude = locationDict?["latitude"] as! NSNumber
                        //print(locationDict?["longitude"] as! NSNumber)
                        let longitude = locationDict?["longitude"] as! NSNumber
                        
                        let location = CLLocation(latitude: CLLocationDegrees(exactly: latitude)!, longitude: CLLocationDegrees(exactly: longitude)!)
                        
                        self.events.append(Event(eventId: event.key, hostId: hostId, name: eventName, address: address, eventTime: eventTime, locationCoordinates: location))
                        
                        self.tableView.reloadData()
                        
                    })
                    
                    
                }
                
                
            }
            
        })
        
    }
    

    @IBAction func onBack(_ sender: UIButton) {
        
        self.navigationController?.popViewController(animated: true)
        
    }
}


extension MyEventsVC : UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return events.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CELL", for: indexPath)
        cell.textLabel!.text = events[indexPath.row].name
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let vc = EventDetailsVC(nibName: "EventDetailsVC", bundle: .main) as EventDetailsVC
        vc.event = events[indexPath.row]
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    
}
