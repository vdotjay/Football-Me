//
//  EventDetailsVC.swift
//  FootballMe
//
//  Created by Vj Dubb on 06/05/2020.
//  Copyright © 2020 Vijender Dubb. All rights reserved.
//

import UIKit
import FirebaseDatabase
import FirebaseAuth
import CoreLocation
import MapKit

class EventDetailsVC: UIViewController {
    
    var event : Event?
    
    let uid = Auth.auth().currentUser!.uid
    let ref = Database.database().reference()
    
    @IBOutlet weak var eventName: UILabel!
    @IBOutlet weak var eventAddress: UILabel!
    @IBOutlet weak var eventTime: UILabel!
    @IBOutlet weak var removeBtn: UIButton!
    @IBOutlet weak var interestedBtn: UIButton!
    
    var isInterested = false
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        if let event = event {
            
            eventName.text = event.name
            eventAddress.text = event.address
            eventTime.text = "Start time : \(event.eventTime)"
            
            if event.hostId != uid {
                removeBtn.isEnabled = false
                removeBtn.isHidden = true
            } else {
                interestedBtn.isEnabled = false
                interestedBtn.isHidden = true
            }
            
        }
        
        
        ref.child(DBKeys.DBMyEventKey).child(uid).child(event!.eventId).observeSingleEvent(of: .value, with: {snapshot in
            
            guard let myEvent = snapshot.value as? Bool else {
                
                self.interestedBtn.setTitle("Mark Interested", for: .normal)
                self.interestedBtn.setTitleColor(.blue, for: .normal)
                self.isInterested = false
                self.ref.child(DBKeys.DBMyEventKey).child(self.uid).child(self.event!.eventId).setValue(true)
                
                return
            }
            
            print(myEvent)
            
            self.isInterested = myEvent
            
            if myEvent {
                self.interestedBtn.setTitle("Remove Interested", for: .normal)
                self.interestedBtn.setTitleColor(.red, for: .normal)
                self.ref.child(DBKeys.DBMyEventKey).child(self.uid).child(self.event!.eventId).setValue(true)
            }
            
        })
        
    }
    
    @IBAction func openLocationOnMap(_ sender: UIButton) {
        
        openMapForPlace(lat: event!.locationCoordinates.coordinate.latitude, long: event!.locationCoordinates.coordinate.longitude, placeName: "Event is here")
    
    }
    
    @IBAction func onMarkInterested(_ sender: UIButton) {
        
        if isInterested {
            
            isInterested = false
            self.interestedBtn.setTitle("Mark Interested", for: .normal)
            self.interestedBtn.setTitleColor(.blue, for: .normal)
            self.ref.child(DBKeys.DBMyEventKey).child(self.uid).child(self.event!.eventId).removeValue()
            
        } else {
            isInterested = true
            self.interestedBtn.setTitle("Remove Interested", for: .normal)
            self.interestedBtn.setTitleColor(.red, for: .normal)
            self.ref.child(DBKeys.DBMyEventKey).child(self.uid).child(self.event!.eventId).setValue(true)
        }
        
    }
    
    @IBAction func onRemove(_ sender: UIButton) {
        
        ref.child(DBKeys.DBEventsKey).child(event!.eventId).removeValue()
        ref.child(DBKeys.DBMyEventKey).child(event!.eventId).removeValue()
        self.navigationController?.popViewController(animated: true)
        
    }
    
    @IBAction func onBack (_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
    public func openMapForPlace(lat:Double = 0, long:Double = 0, placeName:String = "") {
        let latitude: CLLocationDegrees = lat
        let longitude: CLLocationDegrees = long
    
        let regionDistance:CLLocationDistance = 100
        let coordinates = CLLocationCoordinate2DMake(latitude, longitude)
        let regionSpan = MKCoordinateRegion(center: coordinates, latitudinalMeters: regionDistance, longitudinalMeters: regionDistance)
        let options = [
            MKLaunchOptionsMapCenterKey: NSValue(mkCoordinate: regionSpan.center),
            MKLaunchOptionsMapSpanKey: NSValue(mkCoordinateSpan: regionSpan.span)
        ]
        let placemark = MKPlacemark(coordinate: coordinates, addressDictionary: nil)
        let mapItem = MKMapItem(placemark: placemark)
        mapItem.name = placeName
        mapItem.openInMaps(launchOptions: options)
    }
    
    
}
