//
//  AddEventVC.swift
//  FootballMe
//
//  Created by Vj Dubb on 05/05/2020.
//  Copyright © 2020 Vijender Dubb. All rights reserved.
//

import UIKit
import FirebaseDatabase
import FirebaseAuth
import MapKit
import CoreLocation

class AddEventVC: UIViewController, MKMapViewDelegate {
    
    let uid = Auth.auth().currentUser!.uid
    let ref = Database.database().reference()
    
    @IBOutlet weak var eventNameField: UITextField!
    @IBOutlet weak var eventAddressField: UITextField!
    @IBOutlet weak var mapView: MKMapView!
    @IBOutlet weak var dateTimePicker: UIDatePicker!
    
    var eventLocation : CLLocationCoordinate2D!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        mapView.delegate = self
    }

    @IBAction func onAdddEvent(_ sender: UIButton) {
        
        guard let eventName = eventNameField.text else {
            return
        }
        
        guard let eventAddress = eventAddressField.text else {
            return
        }
        
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        
        let eventTime = formatter.string(from: dateTimePicker.date)
        
        let eventId = UUID.init().uuidString
        
        ref.child(DBKeys.DBEventsKey).child(eventId).setValue(["hostid": uid, "eventname" : eventName, "event address": eventAddress, "eventtime" : eventTime, "event Location": ["latitude": eventLocation.latitude, "longitude": eventLocation.longitude]])
        
        ref.child(DBKeys.DBMyEventKey).child(uid).child(eventId).setValue(true)
        
        self.navigationController?.popViewController(animated: true)
        
        
    }
    
    @IBAction func onBack(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
    func mapView(_ mapView: MKMapView, regionDidChangeAnimated animated: Bool) {
        
        eventLocation = mapView.centerCoordinate
        
        let annotations = mapView.annotations
        mapView.removeAnnotations(annotations)
        
        let annotation = MKPointAnnotation()
        annotation.title = "You are here!"
        annotation.coordinate = eventLocation
        mapView.addAnnotation(annotation)

        
    }
    
    
}
