//
//  EventsVC.swift
//  FootballMe
//
//  Created by  Vj Dubb on 23/04/2020.
//  Copyright © 2020 Vijender Dubb. All rights reserved.
//

import UIKit
import FirebaseAuth
import FirebaseDatabase
import CoreLocation


class EventsVC: UIViewController {
    
    let ref = Database.database().reference()
    let uid = Auth.auth().currentUser!.uid
    
    var events = [Event]()

    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var userImage: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        let gesture = UITapGestureRecognizer(target: self, action: #selector(openUser(sender:)))
        userImage.isUserInteractionEnabled = true
        userImage.addGestureRecognizer(gesture)
        
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(true)
        
        self.events.removeAll()
        
        ref.child(DBKeys.DBEventsKey).observe(.value, with: {snapshot in
            
            //print(snapshot.value)
            
            for snap in snapshot.children {
                
                let event = snap as! DataSnapshot
                
                let eventDictionary = event.value as? NSDictionary
                
                //print(eventDictionary?["hostid"] as! String)
                let hostId = eventDictionary?["hostid"] as! String
                //print(eventDictionary?["event address"] as! String)
                
                let eventName = eventDictionary?["eventname"] as! String
                
                let address = eventDictionary?["event address"] as! String
                
                let eventTime = eventDictionary?["eventtime"] as! String
                
                let locationDict = eventDictionary?["event Location"] as? NSDictionary
                
                //print(locationDict?["latitude"] as! NSNumber)
                let latitude = locationDict?["latitude"] as! NSNumber
                //print(locationDict?["longitude"] as! NSNumber)
                let longitude = locationDict?["longitude"] as! NSNumber
                
                let location = CLLocation(latitude: CLLocationDegrees(exactly: latitude)!, longitude: CLLocationDegrees(exactly: longitude)!)
                
                self.events.append(Event(eventId: event.key, hostId: hostId, name: eventName, address: address, eventTime: eventTime, locationCoordinates: location))
                
            }
            
            self.tableView.reloadData()
            
        })
        
    }
    
    @IBAction func openAddEvents(_ sender: UIButton) {
        let vc = AddEventVC(nibName: "AddEventVC", bundle: .main)
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func openMyEvents(_ sender: UIButton) {
        let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "MYEVENT_PAGE") as! MyEventsVC
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func openMap () {
        let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "MAP_PAGE") as! EventMapVC
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func back (_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func openChats(_ sender: UIButton) {
        let c = self.navigationController?.viewControllers.count
        if let _ = self.navigationController?.viewControllers[c! - 2] as? ChatListVC {
            self.navigationController?.popViewController(animated: true)
        } else {
            let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "CHATLIST_PAGE") as! ChatListVC
            self.navigationController?.pushViewController(vc, animated: true)
        }
        
    }
    
    @objc func openUser (sender: UIGestureRecognizer) {
        let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "USER_PAGE")
        self.navigationController?.pushViewController(vc, animated: true)
    }

    
    
    
}

extension EventsVC : UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return events.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CELL", for: indexPath)
        cell.textLabel?.text = events[indexPath.row].name
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let vc = EventDetailsVC(nibName: "EventDetailsVC", bundle: .main) as EventDetailsVC
        vc.event = events[indexPath.row]
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    
}

class Event {
    
    var eventId: String
    var hostId : String
    var name : String
    var address : String
    var eventTime : String
    var locationCoordinates : CLLocation
    
    init(eventId: String, hostId : String, name: String, address : String, eventTime: String, locationCoordinates: CLLocation) {
        self.eventId = eventId
        self.hostId = hostId
        self.name = name
        self.address = address
        self.eventTime = eventTime
        self.locationCoordinates = locationCoordinates
    }
}

