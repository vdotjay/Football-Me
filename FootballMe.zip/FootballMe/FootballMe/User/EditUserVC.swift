//
//  EditUserVC.swift
//  FootballMe
//
//  Created by  Vj Dubb on 18/04/2020.
//  Copyright © 2020 Vijender Dubb. All rights reserved.
//

import UIKit
import FirebaseAuth
import FirebaseDatabase
import FirebaseStorage

class EditUserVC: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate{
    
    var user = UserData()
    
    let ref = Database.database().reference()
    let uid = Auth.auth().currentUser!.uid
    let storageRef = Storage.storage().reference()
    
    @IBOutlet weak var userImage: UIImageView!
    @IBOutlet weak var nameField: UITextField!
    @IBOutlet weak var dobField: UITextField!
    @IBOutlet weak var phoneField: UITextField!
    @IBOutlet weak var availabiltyField: UISwitch!
    
    
    let imagePicker = UIImagePickerController()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        userImage.image = user.image
        nameField.text = user.name
        dobField.text = user.dob
        phoneField.text = user.phone
        availabiltyField.isOn = user.availability!
        
        //Add gesture to image
        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(chooseImage(tapGestureRecognizer:)))
        userImage.isUserInteractionEnabled = true
        userImage.addGestureRecognizer(tapGestureRecognizer)
        //userImage.addGestureRecognizer(UIGestureRecognizer(target: self, action: #selector(chooseImage)))
        
    }
    
    @objc func chooseImage (tapGestureRecognizer: UITapGestureRecognizer) {
        print("image tapped")
        imagePicker.sourceType = .photoLibrary
        imagePicker.mediaTypes = ["public.image"]
        imagePicker.delegate = self
        imagePicker.allowsEditing = true
        self.present(imagePicker, animated: true, completion: nil)

    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        
        let image = info[UIImagePickerController.InfoKey.originalImage] as! UIImage
        userImage.image = image
        imagePicker.dismiss(animated: true, completion: nil)
    }
    
    func goBack () {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func onSave(_ sender: UIButton) {
        
        ref.child(DBKeys.DBUserKey).child(uid).setValue([DBKeys.DBNameKey: nameField.text!, DBKeys.DBDOBKey: dobField.text!, DBKeys.DBPhoneKey: phoneField.text!, DBKeys.DBAvailabilityKey: availabiltyField.isOn, DBKeys.DBUserNameKey: self.user.userName!])
        if let data = userImage.image?.pngData() {
            print("png")
            let progress = storageRef.child(uid).putData(data)
            progress.observe(.success, handler: {snapshot in
                self.goBack()
            })
        } else if let data = userImage.image?.jpegData(compressionQuality: 1) {
            print("jpg")
            let progress = storageRef.child(uid).putData(data)
            
            progress.observe(.success, handler: {snapshot in
                self.goBack()
            })
        }
        
        
        
    }
    
    @IBAction func onBack(_ sender: UIButton) {
        goBack()
    }
    
}
