//
//  OtherUserVC.swift
//  FootballMe
//
//  Created by  Vj Dubb on 11/04/2020.
//  Copyright © 2020 Vijender Dubb. All rights reserved.
//

import UIKit
import FirebaseAuth
import FirebaseDatabase

class OtherUserVC: UIViewController {
    
    @IBOutlet weak var userImage: UIImageView!
    @IBOutlet weak var userNameLabel: UILabel!
    @IBOutlet weak var dobLabel: UILabel!
    @IBOutlet weak var phoneLabel: UILabel!
    @IBOutlet weak var availabilityLabel: UILabel!
    
    var user = UserData()
    
    let ref = Database.database().reference()
    let uid = Auth.auth().currentUser!.uid
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
        userImage.image = user.image
        userNameLabel.text = user.name
        dobLabel.text = user.dob
        phoneLabel.text = user.phone
        availabilityLabel.text = user.availability! ? "Yes" : "No"
        
        
    }
    
    @IBAction func onClickChat(_ sender: UIButton) {
        
        ref.child(DBKeys.DBChatidKey).queryOrdered(byChild: uid).observeSingleEvent(of: .value, with: {snapshot in
            
            if let chatids = snapshot.value as? [String:Any] {
                
                if let chatid = self.doesChatExist(chatIds: chatids) {
                    self.openChat(chatID: chatid)
                } else {
                    self.createNewChat()
                }
                
            } else {
                self.createNewChat()
            }
            
        })
        
    }
    
    func doesChatExist (chatIds: [String: Any]) -> String? {
        
        for id in chatIds {
            print(id.value)
            let participants = id.value as? NSDictionary
            
            if let _ = participants?[self.user.userID!] as? Bool {
                return id.key
            }
            
        }
        
        return nil
        
    }
    
    func createNewChat () {
        let newChatID = UUID.init().uuidString
        self.ref.child(DBKeys.DBChatidKey).child(newChatID).setValue([self.uid: true, self.user.userID!: true])
        openChat(chatID: newChatID)
    }
    
    func openChat (chatID: String) {
        let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "CHAT_PAGE") as! ChatVC
        vc.user = self.user
        vc.chatID = chatID
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func onClickRemove(_ sender: UIButton) {
        ref.child(DBKeys.DBFriendsKey).child(uid).child(user.userID!).removeValue()
        ref.child(DBKeys.DBFriendsKey).child(user.userID!).child(uid).removeValue()
    }
    
    @IBAction func onBack(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func onReview (_ sender: UIButton) {
        let vc = AddReviewVC(nibName: "AddReviewVC", bundle: .main) as AddReviewVC
        vc.user = self.user
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func onCheckSkills (_ sender: UIButton) {
        let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "SKILL_PAGE") as! UserSkillsetVC
        vc.user = self.user
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
}
