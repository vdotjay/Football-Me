//
//  UserSkillsetVC.swift
//  FootballMe
//
//  Created by  Vj Dubb on 19/04/2020.
//  Copyright © 2020 Vijender Dubb. All rights reserved.
//

import UIKit
import FirebaseAuth
import FirebaseDatabase

class UserSkillsetVC: UIViewController {
    
    @IBOutlet weak var userImage: UIImageView!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var collectionView: UICollectionView!
    
    
    @IBOutlet weak var editBtn: UIButton!
    var user = UserData()
    
    var skills = [Skill]()
    var editedFields = [Int]()
    
    let ref = Database.database().reference()
    let uid = Auth.auth().currentUser!.uid
    
    var editMode = false
    var didEdit = false
    
    override func viewDidLoad() {
        super.viewDidLoad()

        userImage.image = user.image
        nameLabel.text = user.name
        editBtn.isEnabled = uid == user.userID!
        editBtn.isHidden = uid != user.userID!
        
        getUserSkills()
        
    }
    
    func getUserSkills () {
        
        ref.child(DBKeys.DBSkillKeys).child(user.userID!).observeSingleEvent(of: .value, with: {snapshot in
            
            //let skills = snapshot.childrenCount
            
            for snap in snapshot.children {
                let userSnap = snap as! DataSnapshot
                let userDict = userSnap.value as! [String:AnyObject] //child data
                let skillName = userDict["Skill Name"] as! String
                let skillRate = userDict["Skill Rate"] as! String
                
                self.skills.append(Skill(skillName: skillName, skillRate: skillRate))
                
            }
            
            self.skills.append(Skill(skillName: "", skillRate: ""))
            
            self.collectionView.reloadData()
            
        })
        
    }
    
    @IBAction func onBack(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func onEdit(_ sender: UIButton) {
        editMode = !editMode
        if editMode {
            editBtn.setTitle("Done", for: .normal)
        } else {
            didEdit = true
            var allowSave = true
            
            for i in editedFields {
                if skills[i].skillName == "" && skills[i].skillRate != "" {
                    allowSave = false
                } else if skills[i].skillName != "" && skills[i].skillRate == "" {
                    allowSave = false
                }
                
            }
            
            
            if allowSave {
            
                for i in editedFields {
                    ref.child(DBKeys.DBSkillKeys).child(user.userID!).child(String(i)).setValue(["Skill Name": skills[i].skillName, "Skill Rate": skills[i].skillRate])
                }
                
                if skills[skills.count-1].skillName != "" {
                    skills.append(Skill(skillName: "", skillRate: ""))
                }
                editBtn.setTitle("Edit", for: .normal)
            
            } else {
                let alert = UIAlertController(title: "Fill Properly", message: "Check all fields", preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
                self.present(alert, animated: true, completion: nil)
                editMode = true
            }
            
            
        }
        
        self.collectionView.reloadData()
    }
    
    
    @objc func skillNameFieldDidChange(_ textField: UITextField) {
        skills[textField.tag].skillName = textField.text!
        if (!editedFields.contains(textField.tag)) {
            editedFields.append(textField.tag)
        }
    }
    
    @objc func skillRateFieldDidChange(_ textField: UITextField) {
        if textField.text!.count > 0 {
            if (Int(textField.text!)! > 5) {
                let alert = UIAlertController(title: "Rating Warning", message: "Add Rating between 0 and 5", preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: {_ in
                    textField.text = ""
                }))
                self.present(alert, animated: true, completion: nil)
            } else {
                skills[textField.tag].skillRate = textField.text!
                if (!editedFields.contains(textField.tag)) {
                    editedFields.append(textField.tag)
                }
            }
        }
        
    }
    
    
}

extension UserSkillsetVC: UICollectionViewDelegate, UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return skills.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CELL", for: indexPath) as! UserSkillCell
        
        if indexPath.row < skills.count {
            cell.skillNameField.text = skills[indexPath.row].skillName
            cell.skillRatingField.text = skills[indexPath.row].skillRate
        }
        
        if editMode {
            cell.skillNameField.isEnabled = true
            cell.skillRatingField.isEnabled = true
            
            cell.skillNameField.isHidden = false
            cell.skillRatingField.isHidden = false
            
            cell.skillNameField.tag = indexPath.row
            cell.skillNameField.addTarget(self, action: #selector(self.skillNameFieldDidChange(_:)), for: UIControl.Event.editingChanged)
            
            cell.skillRatingField.tag = indexPath.row
            cell.skillRatingField.addTarget(self, action: #selector(self.skillRateFieldDidChange(_:)), for: UIControl.Event.editingChanged)
            
        } else {
            cell.skillNameField.isEnabled = false
            cell.skillRatingField.isEnabled = false
            
            if indexPath.row == skills.count-1 {
                cell.skillNameField.isHidden = true
                cell.skillRatingField.isHidden = true
            }
            
        }
        return cell
    }

}

class UserSkillCell : UICollectionViewCell {
    @IBOutlet weak var skillNameField: UITextField!
    @IBOutlet weak var skillRatingField: UITextField!
}


class Skill {
    var skillName : String = ""
    var skillRate : String = ""
    
    init(skillName: String, skillRate : String) {
        self.skillName = skillName
        self.skillRate = skillRate
    }
}
