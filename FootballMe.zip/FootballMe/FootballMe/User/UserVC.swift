//
//  UserVC.swift
//  FootballMe
//
//  Created by  Vj Dubb on 06/04/2020.
//  Copyright © 2020 Vijender Dubb. All rights reserved.
//

import UIKit
import FirebaseAuth
import FirebaseDatabase
import FirebaseStorage

class UserVC: UIViewController {
    
    @IBOutlet weak var userImage: UIImageView!
    @IBOutlet weak var userNameLabel: UILabel!
    @IBOutlet weak var dobLabel: UILabel!
    @IBOutlet weak var phoneLabel: UILabel!
    @IBOutlet weak var availabilitySwitch: UISwitch!
    
    var user = UserData()

    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if (Auth.auth().currentUser != nil) {
            
            let uid = (Auth.auth().currentUser?.uid)!
            
            let ref = Database.database().reference()
            
            ref.child("users").child(uid).observeSingleEvent(of: .value, with: {(snapshot) in
                
                let userData = snapshot.value as? [String:Any]
                
                for data in userData! {
                    
                    if (data.key == "name") {
                        self.userNameLabel.text = data.value as? String
                        self.user.name = data.value as? String
                        
                    } else if (data.key == "dob") {
                        self.dobLabel.text = data.value as? String
                        self.user.dob = data.value as? String
                        
                    } else if (data.key == "phone") {
                        self.phoneLabel.text = data.value as? String
                        self.user.phone = data.value as? String
                        
                    } else if (data.key == "availability") {
                        self.availabilitySwitch.isOn = data.value as? Bool ?? false
                        self.user.availability = data.value as? Bool
                    } else if (data.key == DBKeys.DBUserNameKey) {
                        self.user.userName = data.value as? String
                    }
                    
                }
                self.user.userID = uid
                let storageRef = Storage.storage().reference()
                
                storageRef.child(uid).getData(maxSize: 1 * 1024 * 1024, completion: {data, error in
                    
                    if let error = error  {
                        print(error.localizedDescription)
                        return
                    }
                    
                    let image = UIImage(data: data!)
                    self.userImage.image = image
                    self.user.image = image
                    
                })
                
            })
            
        }
        
    }
    
    @IBAction func onLogout(_ sender: UIButton) {
        
        do {
            try Auth.auth().signOut()
            openLogin()
        } catch {
            print("Error while signing out")
        }
        
    }
    
    func openLogin () {
        let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "LOGIN_PAGE")
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func onBack(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func onEdit(_ sender: UIButton) {
       
        let vc = EditUserVC(nibName: "EditUserVC", bundle: .main) as EditUserVC
        vc.user = self.user
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func openUserSkills(_ sender: UIButton) {
        let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "SKILL_PAGE") as! UserSkillsetVC
        vc.user = self.user
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func openReviews(_ sender: UIButton) {
        let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "REVIEW_PAGE") as! ReviewsVC
        vc.user = self.user
        self.navigationController?.pushViewController(vc, animated: true)
        
        
    }
    
    
}
