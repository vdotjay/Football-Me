//
//  ReviewsVC.swift
//  FootballMe
//
//  Created by  Vj Dubb on 21/04/2020.
//  Copyright © 2020 Vijender Dubb. All rights reserved.
//

import UIKit
import FirebaseDatabase

class ReviewsVC: UIViewController {
    
    let ref = Database.database().reference()
    var user = UserData()
    
    var reviews = [String]()
    
    @IBOutlet weak var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        ref.child(DBKeys.DBReviewKey).child(user.userID!).observeSingleEvent(of: .value, with: {snapshot in
            
            if let reviewSnaps = snapshot.value as? [String:Any] {
                
                for review in reviewSnaps {
                    
                    self.reviews.append(review.value as! String)
                    
                }
                
            }
            
            self.tableView.reloadData()
            
        })
        
    }
    
    func attributedText(withString string: String, boldString: String, font: UIFont) -> NSAttributedString {
        let attributedString = NSMutableAttributedString(string: string,
                                                         attributes: [NSAttributedString.Key.font: font])
        let boldFontAttribute: [NSAttributedString.Key: Any] = [NSAttributedString.Key.font: UIFont.boldSystemFont(ofSize: font.pointSize)]
        let range = (string as NSString).range(of: boldString)
        attributedString.addAttributes(boldFontAttribute, range: range)
        return attributedString
    }
    
    @IBAction func onBack (_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
}

extension ReviewsVC: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return reviews.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CELL", for: indexPath)
        let str = "Review " + String(indexPath.row + 1) + " : " + reviews[indexPath.row]
        cell.textLabel?.attributedText = self.attributedText(withString: str, boldString: "Review " + String(indexPath.row + 1) + " : ", font: cell.textLabel!.font)
        return cell
    }
    
    
    
    
}
