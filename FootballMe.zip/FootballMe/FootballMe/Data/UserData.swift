//
//  UserData.swift
//  FootballMe
//
//  Created by  Vj Dubb on 06/04/2020.
//  Copyright © 2020 Vijender Dubb. All rights reserved.
//

import Foundation
import UIKit


public class UserData {
    
    public var userID : String?
    public var image : UIImage?
    public var name : String?
    public var phone : String?
    public var dob : String?
    public var userName: String?
    public var availability: Bool?
    
    init() {
        
    }
    
    init(userID: String, image : UIImage, name: String, phone: String, dob: String, userName: String, availability: Bool) {
        self.userID = userID
        self.image = image
        self.name = name
        self.phone = phone
        self.dob = dob
        self.userName = userName
        self.availability = availability
    }
    
    static func convertToUserData(dictionary : NSDictionary) -> UserData {
        
        let user = UserData()
        
        user.name = dictionary[DBKeys.DBNameKey] as? String
        user.dob = dictionary[DBKeys.DBDOBKey] as? String
        user.phone = dictionary[DBKeys.DBPhoneKey] as? String
        user.userName = dictionary[DBKeys.DBUserNameKey] as? String
        user.availability = dictionary[DBKeys.DBAvailabilityKey] as? Bool
        
        return user
        
    }
    
}


public class DBKeys {
    
    public static let DBUserKey = "users"
    public static let DBFriendRequestKey = "FriendRequests"
    public static let DBFriendsKey = "Friends"
    public static let DBChatidKey = "ChatIDs"
    public static let DBChatsKey = "Chats"
    public static let DBSkillKeys = "Skills"
    public static let DBReviewKey = "Reviews"
    public static let DBEventsKey = "Events"
    public static let DBMyEventKey = "MyEvents"
    public static let DBNameKey = "name"
    public static let DBAvailabilityKey = "availability"
    public static let DBDOBKey = "dob"
    public static let DBPhoneKey = "phone"
    public static let DBUserNameKey = "username"
    
}


public class Utility {
    
    public static func showAlert (sender: UIViewController, title: String, message: String) {
        
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Dismiss", style: .default, handler: nil))
        sender.present(alert, animated: true, completion: nil)
        
    }
    
}
